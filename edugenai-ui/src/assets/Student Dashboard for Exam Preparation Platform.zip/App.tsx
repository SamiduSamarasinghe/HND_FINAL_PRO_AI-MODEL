import { useState } from 'react';
import { UserTypeSelector } from './components/UserTypeSelector';
import { StudentDashboard } from './components/StudentDashboard';
import { TeacherDashboard } from './components/TeacherDashboard';

export default function App() {
  const [userType, setUserType] = useState<'student' | 'teacher' | null>(null);

  const handleUserTypeChange = (type: 'student' | 'teacher') => {
    setUserType(type);
  };

  const handleBackToSelection = () => {
    setUserType(null);
  };

  if (!userType) {
    return <UserTypeSelector userType={userType || 'student'} onUserTypeChange={handleUserTypeChange} />;
  }

  if (userType === 'teacher') {
    return <TeacherDashboard onUserTypeChange={handleUserTypeChange} />;
  }

  return <StudentDashboard onUserTypeChange={handleUserTypeChange} />;
}