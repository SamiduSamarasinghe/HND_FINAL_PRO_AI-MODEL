import { Sidebar, SidebarContent, SidebarHeader, SidebarMenu, SidebarMenuItem, SidebarMenuButton, SidebarProvider, SidebarTrigger } from "./ui/sidebar";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { Progress } from "./ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";
import { Avatar, AvatarFallback, AvatarImage } from "./ui/avatar";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "./ui/table";
import { 
  Users, 
  FileText, 
  PlusCircle, 
  TrendingUp, 
  BookOpen, 
  Clock, 
  Award, 
  MessageCircle,
  Upload,
  BarChart3,
  Library,
  Settings,
  User,
  Home,
  Brain,
  CheckCircle,
  GraduationCap,
  Target,
  Eye,
  Edit,
  Trash2,
  Download
} from "lucide-react";

interface TeacherDashboardProps {
  onUserTypeChange: (type: 'student' | 'teacher') => void;
}

export function TeacherDashboard({ onUserTypeChange }: TeacherDashboardProps) {
  const classes = [
    { name: "Mathematics 101", students: 32, papers: 8, avgScore: 78, color: "bg-blue-500" },
    { name: "Physics 201", students: 28, papers: 6, avgScore: 82, color: "bg-green-500" },
    { name: "Advanced Calculus", students: 24, papers: 10, avgScore: 75, color: "bg-purple-500" },
    { name: "Statistics", students: 35, papers: 5, avgScore: 85, color: "bg-orange-500" },
  ];

  const recentPapers = [
    { title: "Mathematics Final Exam 2024", questions: 45, status: "Published", created: "2024-01-15", students: 32 },
    { title: "Physics Midterm Draft", questions: 32, status: "Draft", created: "2024-01-14", students: 0 },
    { title: "Calculus Quiz", questions: 20, status: "Published", created: "2024-01-12", students: 24 },
  ];

  const studentPerformance = [
    { name: "Alice Johnson", subject: "Mathematics", score: 92, trend: "up", tests: 8 },
    { name: "Bob Smith", subject: "Physics", score: 85, trend: "up", tests: 6 },
    { name: "Carol Davis", subject: "Mathematics", score: 78, trend: "down", tests: 8 },
    { name: "David Wilson", subject: "Physics", score: 88, trend: "stable", tests: 6 },
    { name: "Eva Brown", subject: "Calculus", score: 94, trend: "up", tests: 10 },
  ];

  const upcomingTasks = [
    { task: "Grade Physics Midterm Papers", due: "Tomorrow", priority: "High" },
    { task: "Create Mathematics Quiz", due: "Jan 18", priority: "Medium" },
    { task: "Review Student Progress Reports", due: "Jan 20", priority: "Low" },
    { task: "Prepare Final Exam Questions", due: "Jan 25", priority: "High" },
  ];

  return (
    <SidebarProvider>
      <div className="flex min-h-screen w-full">
        <Sidebar>
          <SidebarHeader className="p-4">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
                <GraduationCap className="w-5 h-5 text-primary-foreground" />
              </div>
              <div>
                <h2>ExamPrep AI</h2>
                <p className="text-sm text-muted-foreground">Teacher Portal</p>
              </div>
            </div>
          </SidebarHeader>
          <SidebarContent>
            <SidebarMenu>
              <SidebarMenuItem>
                <SidebarMenuButton>
                  <Home className="w-4 h-4" />
                  <span>Dashboard</span>
                </SidebarMenuButton>
              </SidebarMenuItem>
              <SidebarMenuItem>
                <SidebarMenuButton>
                  <Users className="w-4 h-4" />
                  <span>My Classes</span>
                </SidebarMenuButton>
              </SidebarMenuItem>
              <SidebarMenuItem>
                <SidebarMenuButton>
                  <Library className="w-4 h-4" />
                  <span>Question Bank</span>
                </SidebarMenuButton>
              </SidebarMenuItem>
              <SidebarMenuItem>
                <SidebarMenuButton>
                  <FileText className="w-4 h-4" />
                  <span>Create Paper</span>
                </SidebarMenuButton>
              </SidebarMenuItem>
              <SidebarMenuItem>
                <SidebarMenuButton>
                  <Upload className="w-4 h-4" />
                  <span>Upload Papers</span>
                </SidebarMenuButton>
              </SidebarMenuItem>
              <SidebarMenuItem>
                <SidebarMenuButton>
                  <BarChart3 className="w-4 h-4" />
                  <span>Analytics</span>
                </SidebarMenuButton>
              </SidebarMenuItem>
              <SidebarMenuItem>
                <SidebarMenuButton>
                  <TrendingUp className="w-4 h-4" />
                  <span>Student Progress</span>
                </SidebarMenuButton>
              </SidebarMenuItem>
              <SidebarMenuItem>
                <SidebarMenuButton>
                  <MessageCircle className="w-4 h-4" />
                  <span>AI Assistant</span>
                </SidebarMenuButton>
              </SidebarMenuItem>
              <SidebarMenuItem>
                <SidebarMenuButton>
                  <User className="w-4 h-4" />
                  <span>Profile</span>
                </SidebarMenuButton>
              </SidebarMenuItem>
              <SidebarMenuItem>
                <SidebarMenuButton>
                  <Settings className="w-4 h-4" />
                  <span>Settings</span>
                </SidebarMenuButton>
              </SidebarMenuItem>
            </SidebarMenu>
          </SidebarContent>
        </Sidebar>
        
        <main className="flex-1 p-6">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-4">
              <SidebarTrigger />
              <div>
                <h1>Welcome back, Dr. Martinez!</h1>
                <p className="text-muted-foreground">Here's what's happening in your classes today</p>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <Button variant="outline" size="sm" onClick={() => onUserTypeChange('student')}>
                Switch to Student View
              </Button>
              <Button variant="outline" size="sm">
                <MessageCircle className="w-4 h-4 mr-2" />
                AI Assistant
              </Button>
              <Avatar>
                <AvatarImage src="https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=32&h=32&fit=crop&crop=face" />
                <AvatarFallback>DM</AvatarFallback>
              </Avatar>
            </div>
          </div>

          {/* Quick Stats */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">Total Students</p>
                    <p className="text-2xl">119</p>
                  </div>
                  <Users className="w-8 h-8 text-blue-500" />
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">Active Papers</p>
                    <p className="text-2xl">15</p>
                  </div>
                  <FileText className="w-8 h-8 text-green-500" />
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">Questions Created</p>
                    <p className="text-2xl">342</p>
                  </div>
                  <BookOpen className="w-8 h-8 text-purple-500" />
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">Avg Class Score</p>
                    <p className="text-2xl">80%</p>
                  </div>
                  <Award className="w-8 h-8 text-orange-500" />
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Class Overview */}
            <div className="lg:col-span-2">
              <Card>
                <CardHeader>
                  <CardTitle>Class Overview</CardTitle>
                  <CardDescription>Performance summary across all your classes</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {classes.map((classItem, index) => (
                      <div key={index} className="flex items-center justify-between p-4 border rounded-lg">
                        <div className="flex items-center gap-3">
                          <div className={`w-3 h-3 rounded-full ${classItem.color}`}></div>
                          <div>
                            <p className="font-medium">{classItem.name}</p>
                            <p className="text-sm text-muted-foreground">{classItem.students} students • {classItem.papers} papers</p>
                          </div>
                        </div>
                        <div className="flex items-center gap-3">
                          <div className="text-right">
                            <p className="font-medium">{classItem.avgScore}%</p>
                            <p className="text-sm text-muted-foreground">Avg Score</p>
                          </div>
                          <Button variant="outline" size="sm">
                            <Eye className="w-4 h-4" />
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Quick Actions & Tasks */}
            <div>
              <Card>
                <CardHeader>
                  <CardTitle>Quick Actions</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <Button className="w-full justify-start">
                    <PlusCircle className="w-4 h-4 mr-2" />
                    Create New Paper
                  </Button>
                  <Button variant="outline" className="w-full justify-start">
                    <Upload className="w-4 h-4 mr-2" />
                    Upload Questions
                  </Button>
                  <Button variant="outline" className="w-full justify-start">
                    <Users className="w-4 h-4 mr-2" />
                    Manage Classes
                  </Button>
                  <Button variant="outline" className="w-full justify-start">
                    <BarChart3 className="w-4 h-4 mr-2" />
                    View Analytics
                  </Button>
                </CardContent>
              </Card>

              {/* Upcoming Tasks */}
              <Card className="mt-6">
                <CardHeader>
                  <CardTitle>Upcoming Tasks</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {upcomingTasks.map((task, index) => (
                      <div key={index} className="flex items-center justify-between p-2 border rounded">
                        <div className="flex-1">
                          <p className="text-sm font-medium">{task.task}</p>
                          <p className="text-xs text-muted-foreground">{task.due}</p>
                        </div>
                        <Badge variant={task.priority === 'High' ? 'destructive' : task.priority === 'Medium' ? 'default' : 'secondary'}>
                          {task.priority}
                        </Badge>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              {/* AI Assistant Preview */}
              <Card className="mt-6">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Brain className="w-5 h-5" />
                    AI Assistant
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="bg-muted p-3 rounded-lg mb-3">
                    <p className="text-sm">"I can help you create 20 calculus questions focusing on derivatives based on your recent syllabus."</p>
                  </div>
                  <Button size="sm" className="w-full">
                    Get AI Suggestions
                  </Button>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Detailed Information Tabs */}
          <div className="mt-6">
            <Tabs defaultValue="papers" className="w-full">
              <TabsList>
                <TabsTrigger value="papers">Recent Papers</TabsTrigger>
                <TabsTrigger value="students">Student Performance</TabsTrigger>
                <TabsTrigger value="activity">Activity Log</TabsTrigger>
              </TabsList>
              
              <TabsContent value="papers">
                <Card>
                  <CardHeader>
                    <CardTitle>Recent Exam Papers</CardTitle>
                    <CardDescription>Papers you've created and their status</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Paper Title</TableHead>
                          <TableHead>Questions</TableHead>
                          <TableHead>Status</TableHead>
                          <TableHead>Students</TableHead>
                          <TableHead>Created</TableHead>
                          <TableHead>Actions</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {recentPapers.map((paper, index) => (
                          <TableRow key={index}>
                            <TableCell className="font-medium">{paper.title}</TableCell>
                            <TableCell>{paper.questions}</TableCell>
                            <TableCell>
                              <Badge variant={paper.status === 'Published' ? 'default' : 'secondary'}>
                                {paper.status}
                              </Badge>
                            </TableCell>
                            <TableCell>{paper.students}</TableCell>
                            <TableCell>{paper.created}</TableCell>
                            <TableCell>
                              <div className="flex gap-2">
                                <Button variant="outline" size="sm">
                                  <Eye className="w-4 h-4" />
                                </Button>
                                <Button variant="outline" size="sm">
                                  <Edit className="w-4 h-4" />
                                </Button>
                                <Button variant="outline" size="sm">
                                  <Download className="w-4 h-4" />
                                </Button>
                              </div>
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </CardContent>
                </Card>
              </TabsContent>
              
              <TabsContent value="students">
                <Card>
                  <CardHeader>
                    <CardTitle>Student Performance Overview</CardTitle>
                    <CardDescription>Recent performance trends across your classes</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Student Name</TableHead>
                          <TableHead>Subject</TableHead>
                          <TableHead>Latest Score</TableHead>
                          <TableHead>Tests Taken</TableHead>
                          <TableHead>Trend</TableHead>
                          <TableHead>Actions</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {studentPerformance.map((student, index) => (
                          <TableRow key={index}>
                            <TableCell className="font-medium">{student.name}</TableCell>
                            <TableCell>{student.subject}</TableCell>
                            <TableCell>
                              <Badge variant={student.score >= 90 ? 'default' : student.score >= 80 ? 'secondary' : 'destructive'}>
                                {student.score}%
                              </Badge>
                            </TableCell>
                            <TableCell>{student.tests}</TableCell>
                            <TableCell>
                              <div className="flex items-center gap-1">
                                <TrendingUp className={`w-4 h-4 ${
                                  student.trend === 'up' ? 'text-green-500' : 
                                  student.trend === 'down' ? 'text-red-500' : 
                                  'text-gray-500'
                                }`} />
                                <span className="text-sm capitalize">{student.trend}</span>
                              </div>
                            </TableCell>
                            <TableCell>
                              <Button variant="outline" size="sm">
                                View Details
                              </Button>
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </CardContent>
                </Card>
              </TabsContent>
              
              <TabsContent value="activity">
                <Card>
                  <CardHeader>
                    <CardTitle>Recent Activity</CardTitle>
                    <CardDescription>Your recent actions and system events</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      <div className="flex items-center gap-3 p-3 border rounded-lg">
                        <div className="w-8 h-8 bg-blue-100 rounded-lg flex items-center justify-center">
                          <FileText className="w-4 h-4 text-blue-600" />
                        </div>
                        <div className="flex-1">
                          <p className="font-medium">Created Mathematics Final Exam</p>
                          <p className="text-sm text-muted-foreground">45 questions • 2 hours ago</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-3 p-3 border rounded-lg">
                        <div className="w-8 h-8 bg-green-100 rounded-lg flex items-center justify-center">
                          <CheckCircle className="w-4 h-4 text-green-600" />
                        </div>
                        <div className="flex-1">
                          <p className="font-medium">Graded Physics Midterm Papers</p>
                          <p className="text-sm text-muted-foreground">28 papers graded • Yesterday</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-3 p-3 border rounded-lg">
                        <div className="w-8 h-8 bg-purple-100 rounded-lg flex items-center justify-center">
                          <Upload className="w-4 h-4 text-purple-600" />
                        </div>
                        <div className="flex-1">
                          <p className="font-medium">Uploaded question bank for Statistics</p>
                          <p className="text-sm text-muted-foreground">50 new questions • 2 days ago</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-3 p-3 border rounded-lg">
                        <div className="w-8 h-8 bg-orange-100 rounded-lg flex items-center justify-center">
                          <Brain className="w-4 h-4 text-orange-600" />
                        </div>
                        <div className="flex-1">
                          <p className="font-medium">Used AI to generate 20 calculus questions</p>
                          <p className="text-sm text-muted-foreground">Derivatives topic • 3 days ago</p>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </div>
        </main>
      </div>
    </SidebarProvider>
  );
}