import { Button } from "./ui/button";
import { Card, CardContent } from "./ui/card";
import { GraduationCap, BookOpen } from "lucide-react";

interface UserTypeSelectorProps {
  userType: 'student' | 'teacher';
  onUserTypeChange: (type: 'student' | 'teacher') => void;
}

export function UserTypeSelector({ userType, onUserTypeChange }: UserTypeSelectorProps) {
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 flex items-center justify-center p-4">
      <div className="w-full max-w-4xl">
        <div className="text-center mb-8">
          <h1 className="text-4xl mb-4">ExamPrep AI</h1>
          <p className="text-xl text-muted-foreground">Choose your role to continue</p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <Card 
            className={`cursor-pointer transition-all duration-200 hover:shadow-lg ${
              userType === 'student' ? 'ring-2 ring-primary' : ''
            }`}
            onClick={() => onUserTypeChange('student')}
          >
            <CardContent className="p-8 text-center">
              <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <BookOpen className="w-8 h-8 text-blue-600" />
              </div>
              <h3 className="text-xl mb-2">Student Portal</h3>
              <p className="text-muted-foreground mb-6">
                Access your personalized study materials, take mock exams, and track your progress with AI-powered insights.
              </p>
              <Button 
                className="w-full" 
                variant={userType === 'student' ? 'default' : 'outline'}
              >
                Continue as Student
              </Button>
            </CardContent>
          </Card>

          <Card 
            className={`cursor-pointer transition-all duration-200 hover:shadow-lg ${
              userType === 'teacher' ? 'ring-2 ring-primary' : ''
            }`}
            onClick={() => onUserTypeChange('teacher')}
          >
            <CardContent className="p-8 text-center">
              <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <GraduationCap className="w-8 h-8 text-green-600" />
              </div>
              <h3 className="text-xl mb-2">Teacher Portal</h3>
              <p className="text-muted-foreground mb-6">
                Create and manage exam papers, monitor student progress, and utilize AI tools for educational content.
              </p>
              <Button 
                className="w-full" 
                variant={userType === 'teacher' ? 'default' : 'outline'}
              >
                Continue as Teacher
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}