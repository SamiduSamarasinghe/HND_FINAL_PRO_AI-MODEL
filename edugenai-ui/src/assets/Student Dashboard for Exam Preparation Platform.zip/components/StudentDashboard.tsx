import { Sidebar, SidebarContent, SidebarHeader, SidebarMenu, SidebarMenuItem, SidebarMenuButton, SidebarProvider, SidebarTrigger } from "./ui/sidebar";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { Progress } from "./ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";
import { Avatar, AvatarFallback, AvatarImage } from "./ui/avatar";
import { 
  BookOpen, 
  FileText, 
  PlusCircle, 
  TrendingUp, 
  Target, 
  Clock, 
  Award, 
  MessageCircle,
  Upload,
  BarChart3,
  Library,
  Settings,
  User,
  Home,
  Brain,
  CheckCircle
} from "lucide-react";

interface StudentDashboardProps {
  onUserTypeChange: (type: 'student' | 'teacher') => void;
}

export function StudentDashboard({ onUserTypeChange }: StudentDashboardProps) {
  const subjects = [
    { name: "Mathematics", questions: 245, difficulty: "Medium", progress: 75, color: "bg-blue-500" },
    { name: "Physics", questions: 189, difficulty: "Hard", progress: 60, color: "bg-green-500" },
    { name: "Chemistry", questions: 203, difficulty: "Medium", progress: 80, color: "bg-purple-500" },
    { name: "Biology", questions: 167, difficulty: "Easy", progress: 90, color: "bg-orange-500" },
  ];

  const recentPapers = [
    { title: "Mathematics Final Exam 2023", questions: 45, analyzed: true, date: "2024-01-15" },
    { title: "Physics Midterm 2023", questions: 32, analyzed: true, date: "2024-01-12" },
    { title: "Chemistry Quiz 2023", questions: 20, analyzed: false, date: "2024-01-10" },
  ];

  const mockTests = [
    { title: "Mathematics Practice Test #1", score: 85, total: 100, date: "2024-01-14" },
    { title: "Physics Revision Test", score: 78, total: 100, date: "2024-01-13" },
    { title: "Mixed Topics Test", score: 92, total: 100, date: "2024-01-11" },
  ];

  return (
    <SidebarProvider>
      <div className="flex min-h-screen w-full">
        <Sidebar>
          <SidebarHeader className="p-4">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
                <Brain className="w-5 h-5 text-primary-foreground" />
              </div>
              <div>
                <h2>ExamPrep AI</h2>
                <p className="text-sm text-muted-foreground">Student Portal</p>
              </div>
            </div>
          </SidebarHeader>
          <SidebarContent>
            <SidebarMenu>
              <SidebarMenuItem>
                <SidebarMenuButton>
                  <Home className="w-4 h-4" />
                  <span>Dashboard</span>
                </SidebarMenuButton>
              </SidebarMenuItem>
              <SidebarMenuItem>
                <SidebarMenuButton>
                  <Library className="w-4 h-4" />
                  <span>Question Bank</span>
                </SidebarMenuButton>
              </SidebarMenuItem>
              <SidebarMenuItem>
                <SidebarMenuButton>
                  <Upload className="w-4 h-4" />
                  <span>Upload Papers</span>
                </SidebarMenuButton>
              </SidebarMenuItem>
              <SidebarMenuItem>
                <SidebarMenuButton>
                  <FileText className="w-4 h-4" />
                  <span>Generate Test</span>
                </SidebarMenuButton>
              </SidebarMenuItem>
              <SidebarMenuItem>
                <SidebarMenuButton>
                  <BarChart3 className="w-4 h-4" />
                  <span>Analytics</span>
                </SidebarMenuButton>
              </SidebarMenuItem>
              <SidebarMenuItem>
                <SidebarMenuButton>
                  <MessageCircle className="w-4 h-4" />
                  <span>AI Tutor</span>
                </SidebarMenuButton>
              </SidebarMenuItem>
              <SidebarMenuItem>
                <SidebarMenuButton>
                  <User className="w-4 h-4" />
                  <span>Profile</span>
                </SidebarMenuButton>
              </SidebarMenuItem>
              <SidebarMenuItem>
                <SidebarMenuButton>
                  <Settings className="w-4 h-4" />
                  <span>Settings</span>
                </SidebarMenuButton>
              </SidebarMenuItem>
            </SidebarMenu>
          </SidebarContent>
        </Sidebar>
        
        <main className="flex-1 p-6">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-4">
              <SidebarTrigger />
              <div>
                <h1>Welcome back, Sarah!</h1>
                <p className="text-muted-foreground">Ready to continue your exam preparation?</p>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <Button variant="outline" size="sm" onClick={() => onUserTypeChange('teacher')}>
                Switch to Teacher View
              </Button>
              <Button variant="outline" size="sm">
                <MessageCircle className="w-4 h-4 mr-2" />
                Ask AI Tutor
              </Button>
              <Avatar>
                <AvatarImage src="https://images.unsplash.com/photo-1494790108755-2616b612b786?w=32&h=32&fit=crop&crop=face" />
                <AvatarFallback>SA</AvatarFallback>
              </Avatar>
            </div>
          </div>

          {/* Quick Stats */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">Total Questions</p>
                    <p className="text-2xl">804</p>
                  </div>
                  <BookOpen className="w-8 h-8 text-blue-500" />
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">Papers Analyzed</p>
                    <p className="text-2xl">23</p>
                  </div>
                  <FileText className="w-8 h-8 text-green-500" />
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">Mock Tests</p>
                    <p className="text-2xl">12</p>
                  </div>
                  <Target className="w-8 h-8 text-purple-500" />
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">Study Streak</p>
                    <p className="text-2xl">7 days</p>
                  </div>
                  <Award className="w-8 h-8 text-orange-500" />
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Subject Progress */}
            <div className="lg:col-span-2">
              <Card>
                <CardHeader>
                  <CardTitle>Subject Progress</CardTitle>
                  <CardDescription>Your preparation progress across different subjects</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {subjects.map((subject, index) => (
                      <div key={index} className="flex items-center justify-between p-4 border rounded-lg">
                        <div className="flex items-center gap-3">
                          <div className={`w-3 h-3 rounded-full ${subject.color}`}></div>
                          <div>
                            <p className="font-medium">{subject.name}</p>
                            <p className="text-sm text-muted-foreground">{subject.questions} questions</p>
                          </div>
                        </div>
                        <div className="flex items-center gap-3">
                          <Badge variant={subject.difficulty === "Hard" ? "destructive" : subject.difficulty === "Medium" ? "default" : "secondary"}>
                            {subject.difficulty}
                          </Badge>
                          <div className="text-right">
                            <p className="text-sm">{subject.progress}%</p>
                            <Progress value={subject.progress} className="w-20" />
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Quick Actions */}
            <div>
              <Card>
                <CardHeader>
                  <CardTitle>Quick Actions</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <Button className="w-full justify-start">
                    <Upload className="w-4 h-4 mr-2" />
                    Upload New Paper
                  </Button>
                  <Button variant="outline" className="w-full justify-start">
                    <PlusCircle className="w-4 h-4 mr-2" />
                    Generate Mock Test
                  </Button>
                  <Button variant="outline" className="w-full justify-start">
                    <TrendingUp className="w-4 h-4 mr-2" />
                    View Analytics
                  </Button>
                  <Button variant="outline" className="w-full justify-start">
                    <MessageCircle className="w-4 h-4 mr-2" />
                    Chat with AI Tutor
                  </Button>
                </CardContent>
              </Card>

              {/* AI Tutor Preview */}
              <Card className="mt-6">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Brain className="w-5 h-5" />
                    AI Tutor
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="bg-muted p-3 rounded-lg mb-3">
                    <p className="text-sm">"I noticed you're struggling with calculus derivatives. Would you like me to create a focused practice set?"</p>
                  </div>
                  <Button size="sm" className="w-full">
                    Continue Conversation
                  </Button>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Recent Activity Tabs */}
          <div className="mt-6">
            <Tabs defaultValue="papers" className="w-full">
              <TabsList>
                <TabsTrigger value="papers">Recent Papers</TabsTrigger>
                <TabsTrigger value="tests">Mock Tests</TabsTrigger>
                <TabsTrigger value="activity">Study Activity</TabsTrigger>
              </TabsList>
              
              <TabsContent value="papers">
                <Card>
                  <CardHeader>
                    <CardTitle>Recently Uploaded Papers</CardTitle>
                    <CardDescription>Papers you've uploaded for analysis</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      {recentPapers.map((paper, index) => (
                        <div key={index} className="flex items-center justify-between p-3 border rounded-lg">
                          <div>
                            <p className="font-medium">{paper.title}</p>
                            <p className="text-sm text-muted-foreground">{paper.questions} questions • {paper.date}</p>
                          </div>
                          <div className="flex items-center gap-2">
                            {paper.analyzed ? (
                              <Badge variant="secondary" className="gap-1">
                                <CheckCircle className="w-3 h-3" />
                                Analyzed
                              </Badge>
                            ) : (
                              <Badge variant="outline">
                                <Clock className="w-3 h-3 mr-1" />
                                Processing
                              </Badge>
                            )}
                            <Button variant="outline" size="sm">View</Button>
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
              
              <TabsContent value="tests">
                <Card>
                  <CardHeader>
                    <CardTitle>Recent Mock Tests</CardTitle>
                    <CardDescription>Your latest practice test results</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      {mockTests.map((test, index) => (
                        <div key={index} className="flex items-center justify-between p-3 border rounded-lg">
                          <div>
                            <p className="font-medium">{test.title}</p>
                            <p className="text-sm text-muted-foreground">Completed on {test.date}</p>
                          </div>
                          <div className="flex items-center gap-3">
                            <div className="text-right">
                              <p className="font-medium">{test.score}/{test.total}</p>
                              <p className="text-sm text-muted-foreground">{Math.round((test.score / test.total) * 100)}%</p>
                            </div>
                            <Button variant="outline" size="sm">Review</Button>
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
              
              <TabsContent value="activity">
                <Card>
                  <CardHeader>
                    <CardTitle>Study Activity</CardTitle>
                    <CardDescription>Your recent study sessions and progress</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      <div className="flex items-center gap-3 p-3 border rounded-lg">
                        <div className="w-8 h-8 bg-blue-100 rounded-lg flex items-center justify-center">
                          <BookOpen className="w-4 h-4 text-blue-600" />
                        </div>
                        <div className="flex-1">
                          <p className="font-medium">Practiced 25 Mathematics questions</p>
                          <p className="text-sm text-muted-foreground">2 hours ago</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-3 p-3 border rounded-lg">
                        <div className="w-8 h-8 bg-green-100 rounded-lg flex items-center justify-center">
                          <Target className="w-4 h-4 text-green-600" />
                        </div>
                        <div className="flex-1">
                          <p className="font-medium">Completed Physics Mock Test</p>
                          <p className="text-sm text-muted-foreground">Yesterday</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-3 p-3 border rounded-lg">
                        <div className="w-8 h-8 bg-purple-100 rounded-lg flex items-center justify-center">
                          <Upload className="w-4 h-4 text-purple-600" />
                        </div>
                        <div className="flex-1">
                          <p className="font-medium">Uploaded Chemistry Final Exam</p>
                          <p className="text-sm text-muted-foreground">2 days ago</p>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </div>
        </main>
      </div>
    </SidebarProvider>
  );
}